﻿Imports System.Data.Common
Imports System.Data.SqlClient

Public Class DataAccess
    Private Const ConnStr As String = "Data Source=.;Initial Catalog=StudetntDB;Integrated Security=True"

        Public Shared Function GetSingleItems(ByVal sql As String, ByVal Optional dbParameter As List(Of SqlParameter) = Nothing) As Object
        Dim conn As New SqlConnection(ConnStr)
        Dim obj As Object
        Try
            conn.Open()
            Dim cmd As SqlCommand = New SqlCommand(sql, conn)
            If Not IsNothing(dbParameter) AndAlso dbParameter.Count > 0 Then
                For Each p As Object In dbParameter
                    cmd.Parameters.Add(p)
                Next
            End If
            obj = cmd.ExecuteScalar()
        Catch e As Exception
            Throw
        Finally
            conn.Close()
        End Try
        Return obj
    End Function
Public Shared Function InsertUpdateDelete(ByVal sql As String, ByVal Optional dbParameter As List(Of SqlParameter) = Nothing) As Integer
        Dim rows As Integer = 0
        Dim conn As SqlConnection = New SqlConnection(ConnStr)
        Try
            conn.Open()
            Dim cmd As SqlCommand = New SqlCommand(sql, conn)
            If Not IsNothing(dbParameter) AndAlso dbParameter.Count > 0 Then
                For Each p As Object In dbParameter
                    cmd.Parameters.Add(p)
                Next
            End If
            rows = cmd.ExecuteNonQuery()
        Catch e As Exception
            Throw
        Finally
            conn.Close()
        End Try

        Return rows
    End Function
    Public Shared Function GetMultitpleItems(ByVal sql As String, ByVal Optional dbParameter As List(Of SqlParameter) = Nothing) As DataTable
        Dim conn As New SqlConnection(ConnStr)
        Dim dt As New DataTable
        Try
            conn.Open()
            Dim da As SqlDataAdapter = New SqlDataAdapter()
            Dim cmd As SqlCommand = New SqlCommand(sql, conn)
            If Not IsNothing(dbParameter) AndAlso dbParameter.Count > 0 Then
                For Each p As Object In dbParameter
                    cmd.Parameters.Add(p)
                Next
            End If
            da.SelectCommand=cmd
            da.Fill(dt)
        Catch e As Exception
            Throw
        Finally
            conn.Close()
        End Try
        Return dt
    End Function

End Class
