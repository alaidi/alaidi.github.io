﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnExchange = New System.Windows.Forms.Button()
        Me.btnGenericClass = New System.Windows.Forms.Button()
        Me.btnStudentArray = New System.Windows.Forms.Button()
        Me.btnIComparerGeneric = New System.Windows.Forms.Button()
        Me.btnDictionary = New System.Windows.Forms.Button()
        Me.SuspendLayout
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(65, 99)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(185, 140)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = true
        '
        'btnExchange
        '
        Me.btnExchange.Location = New System.Drawing.Point(256, 99)
        Me.btnExchange.Name = "btnExchange"
        Me.btnExchange.Size = New System.Drawing.Size(185, 140)
        Me.btnExchange.TabIndex = 0
        Me.btnExchange.Text = "Button1"
        Me.btnExchange.UseVisualStyleBackColor = true
        '
        'btnGenericClass
        '
        Me.btnGenericClass.Location = New System.Drawing.Point(65, 245)
        Me.btnGenericClass.Name = "btnGenericClass"
        Me.btnGenericClass.Size = New System.Drawing.Size(185, 140)
        Me.btnGenericClass.TabIndex = 0
        Me.btnGenericClass.Text = "GenericClass "
        Me.btnGenericClass.UseVisualStyleBackColor = true
        '
        'btnStudentArray
        '
        Me.btnStudentArray.Location = New System.Drawing.Point(256, 245)
        Me.btnStudentArray.Name = "btnStudentArray"
        Me.btnStudentArray.Size = New System.Drawing.Size(185, 140)
        Me.btnStudentArray.TabIndex = 0
        Me.btnStudentArray.Text = "StudentArray"
        Me.btnStudentArray.UseVisualStyleBackColor = true
        '
        'btnIComparerGeneric
        '
        Me.btnIComparerGeneric.Location = New System.Drawing.Point(447, 99)
        Me.btnIComparerGeneric.Name = "btnIComparerGeneric"
        Me.btnIComparerGeneric.Size = New System.Drawing.Size(185, 140)
        Me.btnIComparerGeneric.TabIndex = 0
        Me.btnIComparerGeneric.Text = "IComparerGeneric"
        Me.btnIComparerGeneric.UseVisualStyleBackColor = true
        '
        'btnDictionary
        '
        Me.btnDictionary.Location = New System.Drawing.Point(447, 245)
        Me.btnDictionary.Name = "btnDictionary"
        Me.btnDictionary.Size = New System.Drawing.Size(185, 140)
        Me.btnDictionary.TabIndex = 0
        Me.btnDictionary.Text = "Dictionary"
        Me.btnDictionary.UseVisualStyleBackColor = true
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(924, 450)
        Me.Controls.Add(Me.btnStudentArray)
        Me.Controls.Add(Me.btnGenericClass)
        Me.Controls.Add(Me.btnDictionary)
        Me.Controls.Add(Me.btnIComparerGeneric)
        Me.Controls.Add(Me.btnExchange)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Student Application"
        Me.ResumeLayout(false)

End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents btnExchange As Button
    Friend WithEvents btnGenericClass As Button
    Friend WithEvents btnStudentArray As Button
    Friend WithEvents btnIComparerGeneric As Button
    Friend WithEvents btnDictionary As Button
End Class
