﻿
Public Enum SORTFIELD As Integer
        FIRSTNAME
        LASTNAME
        ID
        TEST1SCORE
        TEST2SCORE
    End Enum

Public  Enum SORTDIR As Integer
        ASC
        DESC
    End Enum

'Class StudentComparer

'    Implements IComparer(Of Student2)

'    Public Property SortTheField As SORTFIELD = SORTFIELD.ID

'    Public Property SortDir As SORTDIR = SORTDIR.ASC

'    Public Function Compare(ByVal x As Student2, ByVal y As Student2) As Integer Implements IComparer(Of Student2).Compare
'        Dim res As Integer = x.CompareTo(y, SortTheField)
'        If sortDir = SORTDIR.DESC Then res = - 1*res
'        Return res
'    End Function
'End Class
Class StudentComparer2
    Implements IComparer(Of Student2)
    Public Property SortFields As SORTFIELD = SORTFIELD.ID
    Public Property SortDirs As SORTDIR = SORTDIR.ASC
    Public Function Compare(ByVal x As Student2, ByVal y As Student2) As Integer Implements IComparer(Of Student2).Compare
        Dim res As Integer = x.CompareTo(y, SortFields)
        If SortDirs = SORTDIR.DESC Then res = -1 * res
        Return res
    End Function
End Class