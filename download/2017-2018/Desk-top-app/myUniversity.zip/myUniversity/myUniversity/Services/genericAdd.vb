﻿Imports myUniversity

Class GenUtil
    Public Shared Sub Exchange(Of myType)(ByRef a As myType, ByRef b As myType)
        Dim temp As myType = a
        a = b
        b = temp
    End Sub
End Class
Class MyGen(Of T1, T2)
    Public Property A As T1
    Public Property B As T2
    Public Overrides Function ToString() As String
        Return A.ToString() & " : " & B.ToString()
    End Function
End Class
Public Class GenArr
    Public Shared Function InitArray(Of T As New)(ByVal size As Integer) As T()
        Dim arr As T() = New T(size - 1) {}
        For i As Integer = 0 To size - 1
            arr(i) = New T()
        Next
        Return arr
    End Function
    Public Shared Function FindMax(Of T As IComparable)(ByVal arr As T()) As T
        Dim max As T = arr(0)
        For i As Integer = 1 To arr.Length-1
            If arr(i).CompareTo(max) = 1 Then max = arr(i)
        Next
        Return max
    End Function
    Public Shared Function FindMin(Of T As IComparable(Of T))(ByVal arr As T()) As T
        Dim max As T = arr(0)
        For i As Integer = 1 To arr.Length
                 If arr(i).CompareTo(max) = 1 Then max = arr(i)
           Next
        Return max
    End Function
End Class
Public Class Student2 
    Implements IComparable(of Student2),IComparable
    Public Property FirstName As String
    Public Property LastName As String
    Public Property Id As Integer
    Public Property Test1Score As Integer
    Public Property Test2Score As Integer

    Public Overrides Function ToString() As String
        Return FirstName & " " & LastName & " " + Id.ToString() & " " + Test1Score.ToString() & " " + Test2Score.ToString()
    End Function

    Public Function CompareTo(obj As Object) As Integer Implements IComparable.CompareTo
        Dim res As Integer = 0
        Dim st As Student2 = Nothing
        If TypeOf obj Is Student2 Then
            st = CType(obj, Student2)
            res = Me.Test1Score.CompareTo(st.Test1Score)
        End If
        Return res

    End Function

    Public Function CompareTo(ByVal st As Student2, ByVal sField As SORTFIELD) As Integer 'Implements IComparable(Of Student2).CompareTo
        Dim res As Integer = 0
        Select Case sField
            Case SORTFIELD.FIRSTNAME
                res = FirstName.CompareTo(st.FirstName)
            Case SORTFIELD.LASTNAME
                res = LastName.CompareTo(st.LastName)
            Case SORTFIELD.ID
                res = Me.Id.CompareTo(st.Id)
            Case SORTFIELD.TEST1SCORE
                res = Me.Test1Score.CompareTo(st.Test1Score)
            Case SORTFIELD.TEST2SCORE
                res = Me.Test2Score.CompareTo(st.Test2Score)
        End Select

        Return res
    End Function
    Public Function CompareTo(ByVal other As Student2) As Integer Implements IComparable(Of Student2).CompareTo
        Return Me.Test1Score.CompareTo(other.Test1Score)
    End Function


    'Public Function CompareTo(obj As Object) As Integer Implements IComparable.CompareTo
    '    Dim res As Integer = 0
    '    Dim st As Student2 = Nothing
    '    If TypeOf obj Is Student2 Then
    '        st = CType(obj, Student2)
    '        res = Me.Test1Score.CompareTo(st.Test1Score)
    '    End If
    '    Return res
    'End Function
End Class

'Public Class Student3
'    Implements IComparable(Of Student3)
'    Public Property FirstName As String
'    Public Property LastName As String
'    Public Property Id As Integer
'    Public Property Test1Score As Integer
'    Public Property Test2Score As Integer
'    Public Overrides Function ToString() As String
'        Return FirstName & " " & LastName & " " + Id.ToString() & " " + Test1Score.ToString() & " " + Test2Score.ToString()
'    End Function
'    Public Function CompareTo(ByVal other As Student3) As Integer Implements IComparable(Of Student3).CompareTo
'        Return Me.Test1Score.CompareTo(other.Test1Score)
'    End Function
'End Class