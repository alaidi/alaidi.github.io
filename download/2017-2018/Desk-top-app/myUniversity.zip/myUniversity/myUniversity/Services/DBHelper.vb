﻿Imports System.Reflection

Public Interface IEntity
     Property Id As Integer
     Property Name As String
    Sub PopulateFields(ByVal dr As DataRow)
End Interface
Public Class DBHelper
    Public Shared Function GetList(Of T As {IEntity, New})(ByVal dt As DataTable) As List(Of T)
        Dim TList As List(Of T) = New List(Of T)()
        For Each dr As DataRow In dt.Rows
            Dim t1 As T = New T()
            t1.PopulateFields(dr)
            TList.Add(t1)
        Next

        Return TList
    End Function
End Class
Public Class MyEntityBase
    Implements IEntity
    Public Property Id As Integer Implements IEntity.Id
    Public Property Name As String Implements IEntity.Name

    Public Sub PopulateFields(ByVal dr As DataRow) Implements IEntity.PopulateFields
        Dim tp As Type = Me.[GetType]()
        For Each pi As PropertyInfo In tp.GetProperties()
            pi.SetValue(Me, dr(pi.Name))
        Next
    End Sub
End Class
