﻿Public Class Department
    Inherits MyEntityBase
End Class
