﻿Public Class myUser
    Inherits MyEntityBase
    Public Property Password As String

    Public Property salt As String

End Class
