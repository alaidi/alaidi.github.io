﻿Public Class College
    Inherits MyEntityBase
    Property Location As String

End Class
