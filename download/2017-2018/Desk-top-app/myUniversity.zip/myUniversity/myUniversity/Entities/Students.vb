﻿Public Class Student
    Inherits MyEntityBase
    Public Property Birthday As DateTime
    Public Property Sex As Boolean
End Class
