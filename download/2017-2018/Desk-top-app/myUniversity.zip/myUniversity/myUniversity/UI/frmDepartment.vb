﻿Imports myUniversity.BLL

Public Class frmDepartment
    Dim deprepo = New DepartmentRepository

    Private Sub frmDepartment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim department As New Department
        'department.Id = 3
        'department.Name = "test"
        'deprepo.Add(department)
        dgvDepartment.DataSource = deprepo.Read(new Department)
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim department As New Department
        department.Id = txtDepId.Text
        department.Name = txtName.Text
        If deprepo.Add(department) > 0 Then
            MessageBox.Show("Add Seccesfully")
            dgvDepartment.DataSource = deprepo.Read()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim dep As New Department
        dep.Id = txtDepId.Text
        dep.Name = txtName.Text
        If deprepo.Update(dep) > 0 Then
            MessageBox.Show("update Done")
            dgvDepartment.DataSource = deprepo.Read()
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim dep As New Department
        dep.Id = txtDepId.Text
        If deprepo.Delete(dep) > 0 Then
            MessageBox.Show("Delete Done")
            dgvDepartment.DataSource = deprepo.Read()

        End If
    End Sub

    Private Sub frmDepartment_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        Form1.Show()
    End Sub
End Class