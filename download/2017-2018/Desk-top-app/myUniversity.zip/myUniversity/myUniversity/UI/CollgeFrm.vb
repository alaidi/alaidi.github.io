﻿Public Class CollgeFrm
    Dim collrep As New CollegeRepository
    Private Sub CollgeFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.DataSource=collrep.Read(New College())
    End Sub
End Class