﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frm As New frmDepartment
        Me.Hide()
        frm.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnExchange_Click(sender As Object, e As EventArgs) Handles btnExchange.Click
        Dim x As Double = 7.5
        Dim y As Double = 3.2
        MessageBox.Show("Before Exchange: " + x.ToString() + " " + y.ToString())
        GenUtil.Exchange(x, y)
        MessageBox.Show("After Exchange: " + x.ToString() + " " + y.ToString())
    End Sub

    Private Sub btnGenericClass_Click(sender As Object, e As EventArgs) Handles btnGenericClass.Click
        Dim mg = New MyGen(Of Integer, Single)()
        mg.A = 5
        mg.B = 3.75F
        MessageBox.Show(mg.ToString())
    End Sub

    Private Sub btnStudentArray_Click(sender As Object, e As EventArgs) Handles btnStudentArray.Click
          Dim  stArr2 =GenArr.InitArray(Of Student)(5)' New Student(5){}
        MessageBox.Show(stArr2.Length)

        'For i As Integer = 0 To stArr.Length
        '    stArr(i)=New Student()
        'Next

        Dim stArr = GenArr.InitArray(Of Student2)(3)
        stArr(0).Id = 12345
        stArr(0).FirstName = "Bill"
        stArr(0).Test1Score = 83
        stArr(1).Id = 12346
        stArr(1).FirstName = "Mark"
        stArr(1).Test1Score = 85
        stArr(2).Id = 12348
        stArr(2).FirstName = "Sally"
        stArr(2).Test1Score = 91
        Dim maxScoreStudent = GenArr.FindMax(of Student2)(stArr)
        MessageBox.Show(maxScoreStudent.ToString())


    End Sub

    Private Sub btnIComparerGeneric_Click(sender As Object, e As EventArgs) Handles btnIComparerGeneric.Click
        Dim STList As List(Of Student2) = New List(Of Student2)
        Dim s1 As Student2 = New Student2 With {
            .FirstName = "Bil",
            .LastName = "Baker",
            .Test1Score = 85,
            .Test2Score = 91,
            .Id = 12345
        }
        STList.Add(s1)
        Dim s2 As Student2 = New Student2() With {
            .FirstName = "Sally",
            .LastName = "Simpson",
            .Test1Score = 89,
            .Test2Score = 93,
            .Id = 12348
        }
        STList.Add(s2)
        Dim s3 As Student2 = New Student2() With {
            .FirstName = "Mark",
            .LastName = "Williams",
            .Test1Score = 81,
            .Test2Score = 87,
            .Id = 12347
        }
        STList.Add(s3)
        Dim s4 As Student2 = New Student2() With {
            .FirstName = "James",
            .LastName = "Jacobs",
            .Test1Score = 80,
            .Test2Score = 77,
            .Id = 12346
        }
        STList.Add(s4)
        Dim sc As StudentComparer2 = New StudentComparer2
        sc.SortFields = SORTFIELD.TEST2SCORE
        sc.SortDirs = SORTDIR.DESC
        STList.Sort(sc)
        Dim out1 As String = ""
        For Each st As Student2 In STList
            out1 = (out1 + (st.ToString + vbLf))
        Next
        MessageBox.Show(out1)
        sc.SortFields = SORTFIELD.TEST2SCORE
        sc.SortDirs = SORTDIR.ASC
        STList.Sort(sc)
        out1 = ""
        For Each st As Student2 In STList
            out1 = (out1 + (st.ToString + vbLf))
        Next
        MessageBox.Show(out1)
    End Sub

    Private Sub btnDictionary_Click(sender As Object, e As EventArgs) Handles btnDictionary.Click
        Dim DTable As Dictionary(Of Integer, Student2) = New Dictionary(Of Integer, Student2)

        Dim s1 As Student2 = New Student2 With {
                .FirstName = "Bil",
                .LastName = "Baker",
                .Test1Score = 85,
                .Test2Score = 91,
                .Id = 12345
                }
        DTable.Add(s1.Id, s1)
        Dim s2 As Student2 = New Student2() With {
                .FirstName = "Sally",
                .LastName = "Simpson",
                .Test1Score = 89,
                .Test2Score = 93,
                .Id = 12365
                }
        DTable.Add(s2.Id, s2)
        Dim id As Integer = 12365
        Try
            Dim st As Student2 = DTable(id)
            MessageBox.Show(st.ToString)
        Catch ex As KeyNotFoundException
            MessageBox.Show("Student does not exist")
        End Try
    End Sub
End Class
