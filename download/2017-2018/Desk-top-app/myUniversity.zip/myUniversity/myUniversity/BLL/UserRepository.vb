﻿Imports System.Data.Common
Imports System.Data.SqlClient

Public Class UserRepository
    Inherits GenericRepo(Of myUser)

'    Implements IUserRepository
'    Public  Function Add(user As myUser) As Integer Implements IUserRepository.Add
'        Dim sql = "INSERT INTO [UserTable]([Name],[Password],[salt])VALUES (@Name,@Password,@salt)"
'        Dim plist As New List(Of SqlParameter) From {
'            New SqlParameter("@Name", user.Name),
'            New SqlParameter("@Password", user.Password),
'            New SqlParameter("@salt", user.Password)
'        }
'        Return DataAccess.InsertUpdateDelete(sql, plist)
'    End Function
'    Public  Function Update(user As myUser) As Integer Implements IUserRepository.Update
'        Dim sql = "UPDATE [UserTable]   SET [Name] = @Name,[Password] = @Password,[salt] = @salt WHERE id=@id"
'        Dim plist As New List(Of SqlParameter) From {
'                New SqlParameter("@Name", user.Name),
'                New SqlParameter("@Password", user.Password),
'                New SqlParameter("@salt", user.Password),
'                New SqlParameter("@id", user.Id)
'                }
'        Return DataAccess.InsertUpdateDelete(sql, plist)
'    End Function
'    Public  Function Delete(user As myUser) As Integer Implements IUserRepository.Delete
'        Dim sql = "DELETE FROM [UserTable] WHERE Id=@id"
'        Dim plist As New List(Of SqlParameter) From {
'                New SqlParameter("@id", user.Id)
'                }
'        Return DataAccess.InsertUpdateDelete(sql, plist)
'    End Function
'    Public  Function Read() As List(Of myUser) Implements IUserRepository.Read
'        Dim sql = "Select * from [UserTable] "
'        Dim dt = DataAccess.GetMultitpleItems(sql)
'        Dim uList = New List(Of myUser)
'        For Each r As Object In dt.Rows
'            Dim u As New myUser
'            u.Id = r(0)
'            u.Name = r(1)
'            u.Password = r(2)
'            u.salt = r(3)
'            uList.Add(u)
'        Next
'        Return uList
'    End Function
End Class
