﻿Imports myUniversity

Public Interface IStudentRepository
    Inherits IRepository(of Student)
End Interface
