﻿Public Class CollegeRepository
    Inherits GenericRepo(Of College)
End Class
