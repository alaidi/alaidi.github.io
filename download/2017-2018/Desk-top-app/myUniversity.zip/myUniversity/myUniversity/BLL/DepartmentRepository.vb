﻿Imports System.Data.Common
Imports System.Data.SqlClient

Namespace BLL

    Public Class DepartmentRepository
        Inherits GenericRepo(Of Department)
        'Implements IDepartmentRepository
        'Public Function Add(dep As Department) As Integer Implements IRepository(Of Department).Add
        '    Dim type As Type = dep.GetType()
        '    Dim typeName As String = type.Name
        '    Dim sql = "INSERT INTO [Department]([Name])VALUES (@Name)"
        '    Dim plist As New List(Of SqlParameter) From {
        '            New SqlParameter("@Name", dep.Name)
        '            }
        '    Return DataAccess.InsertUpdateDelete(sql, plist)
        'End Function
        'Public Function Update(user As Department) As Integer Implements IRepository(Of Department).Update
        '    Dim sql = "UPDATE [Department]   SET [Name] = @Name WHERE id=@id"
        '    Dim plist As New List(Of SqlParameter) From {
        '            New SqlParameter("@Name", user.Name),
        '            New SqlParameter("@id", user.Id)
        '            }
        '    Return DataAccess.InsertUpdateDelete(sql, plist)
        'End Function
        'Public Function Delete(user As Department) As Integer Implements IRepository(Of Department).Delete
        '    Dim sql = "DELETE FROM [Department] WHERE Id=@id"
        '    Dim plist As New List(Of SqlParameter) From {
        '            New SqlParameter("@id", user.Id)
        '            }
        '    Return DataAccess.InsertUpdateDelete(sql, plist)
        'End Function
        'Public Function Read() As List(Of Department) Implements IRepository(Of Department).Read

        '    'Dim type As Type = dep.GetType()
        '    'Dim typeName As String = type.FullName

        '    Dim sql = "Select * from [Department] "
        '    Dim dt = DataAccess.GetMultitpleItems(sql)
        '    Dim dList =DBHelper.GetList(of Department)(dt)
        '    '    New List(Of Department)
        '    'For Each r As Object In dt.Rows
        '    '    Dim u As New Department
        '    '    u.Id = r(0)
        '    '    u.Name = r(1)
        '    '    dList.Add(u)
        '    'Next
        '    Return dList
        'End Function
    End Class
End NameSpace