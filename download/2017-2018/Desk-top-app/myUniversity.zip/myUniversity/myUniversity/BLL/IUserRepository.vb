﻿Public Interface IUserRepository
Inherits IRepository(Of myUser)
End Interface
