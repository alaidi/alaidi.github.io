﻿Imports System.Data.SqlClient

Public Interface IRepository (Of T)
    Function Add(model As T) As Integer
    Function Update(model As T) As Integer
    Function Delete(model As T) As Integer
    Function Read(model As T) As List(Of T)
   
End Interface

Public Interface IDepartmentRepository
    Inherits IRepository(Of Department)
End Interface

'Public Class DepartmentRepository (of T)
'        Implements IRepository(Of T)
'    Public Function Add(dep As T) As Integer Implements IRepository(Of T).Add
'            Dim type As Type = dep.GetType()
'            Dim typeName As String = type.Name
'            Dim sql = "INSERT INTO [Department]([Name])VALUES (@Name)"
'            Dim plist As New List(Of SqlParameter) From {
'                    New SqlParameter("@Name", dep.Name)
'                    }
'            Return DataAccess.InsertUpdateDelete(sql, plist)
'        End Function
'        Public Function Update(user As T) As Integer Implements IRepository(Of T).Update
'            Dim sql = "UPDATE [Department]   SET [Name] = @Name WHERE id=@id"
'            Dim plist As New List(Of SqlParameter) From {
'                    New SqlParameter("@Name", user.Name),
'                    New SqlParameter("@id", user.Id)
'                    }
'            Return DataAccess.InsertUpdateDelete(sql, plist)
'        End Function
'        Public Function Delete(user As T) As Integer Implements IRepository(Of T).Delete
'            Dim sql = "DELETE FROM [Department] WHERE Id=@id"
'            Dim plist As New List(Of SqlParameter) From {
'                    New SqlParameter("@id", user.Id)
'                    }
'            Return DataAccess.InsertUpdateDelete(sql, plist)
'        End Function
'        Public Function Read() As List(Of T) Implements IRepository(Of T).Read

'            'Dim type As Type = dep.GetType()
'            'Dim typeName As String = type.FullName

'            Dim sql = "Select * from [Department] "
'            Dim dt = DataAccess.GetMultitpleItems(sql)
'            Dim dList =DBHelper.GetList(of T)(dt)
'            '    New List(Of Department)
'            'For Each r As Object In dt.Rows
'            '    Dim u As New Department
'            '    u.Id = r(0)
'            '    u.Name = r(1)
'            '    dList.Add(u)
'            'Next
'            Return dList
'        End Function
'    End Class

