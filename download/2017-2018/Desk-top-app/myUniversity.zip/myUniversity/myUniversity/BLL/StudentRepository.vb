﻿Imports System.Data.Common
Imports System.Data.SqlClient

Public Class StudentRepository
    Inherits GenericRepo(Of Student)

'    Implements IStudentRepository
'    Public Function Add(user As Student) As Integer Implements IRepository(Of Student).Add
'        Dim sql = "INSERT INTO [Student]([Name])VALUES (@Name)"
'        Dim plist As New List(Of SqlParameter) From {
'                New SqlParameter("@Name", user.Name)
'                }
'        Return DataAccess.InsertUpdateDelete(sql, plist)
'    End Function
'    Public Function Update(user As Student) As Integer Implements IRepository(Of Student).Update
'        Dim sql = "UPDATE [Student]   SET [Name] = @Name WHERE id=@id"
'        Dim plist As New List(Of SqlParameter) From {
'                New SqlParameter("@Name", user.Name),
'                New SqlParameter("@id", user.Id)
'                }
'        Return DataAccess.InsertUpdateDelete(sql, plist)
'    End Function
'    Public Function Delete(user As Student) As Integer Implements IRepository(Of Student).Delete
'        Dim sql = "DELETE FROM [Student] WHERE Id=@id"
'        Dim plist As New List(Of SqlParameter) From {
'                New SqlParameter("@id", user.Id)
'                }
'        Return DataAccess.InsertUpdateDelete(sql, plist)
'    End Function
'    Public Function Read() As List(Of Student) Implements IRepository(Of Student).Read
'        Dim sql = "Select * from [Student] "
'        dim dt = DataAccess.GetMultitpleItems(sql)
'        Dim dList = DBHelper.GetList(of Student)(dt)
'        '    New List(Of Student)
'        'For Each r As Object In dt.Rows
'        '    Dim u As New Student
'        '    u.Id = r(0)
'        '    u.Name = r(1)
'        '    dList.Add(u)
'        'Next
'        Return dList
'    End Function
End Class
