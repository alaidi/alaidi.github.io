﻿Imports System.Data.SqlClient
Imports System.Reflection

Public Class GenericRepo(Of T As {IEntity,New})
    Implements IRepository(Of T)

    Public Function Add(model As T) As Integer Implements IRepository(Of T).Add
        Dim sql2 = ""
        Dim sql3 = ")VALUES ("
        Dim plist As New List(Of SqlParameter)
        For Each p As PropertyInfo In model.GetType().GetProperties()
            sql2 += " " + p.Name + ","
            sql3 += "@" + p.Name + ","
            Dim per = New SqlParameter("@" + p.Name, p.GetValue(model))
            plist.Add(per)
        Next
        Dim sql = "INSERT INTO " + model.GetType().Name + "(" + sql2.Remove(sql2.Count() - 1) + sql3.Remove(sql3.Count() - 1) + ")"

        Return DataAccess.InsertUpdateDelete(sql, plist)
    End Function

    Public Function Update(model As T) As Integer Implements IRepository(Of T).Update
        Throw New NotImplementedException
    End Function

    Public Function Delete(model As T) As Integer Implements IRepository(Of T).Delete
        Throw New NotImplementedException
    End Function

    Public Function Read(model As  T) As List(Of T) Implements IRepository(Of T).Read
        Dim sql = "Select * from ["+model.GetType().Name+"] "
        dim dt = DataAccess.GetMultitpleItems(sql)
        Dim dList = DBHelper.GetList(of T)(dt)
        Return dList
    End Function
End Class
