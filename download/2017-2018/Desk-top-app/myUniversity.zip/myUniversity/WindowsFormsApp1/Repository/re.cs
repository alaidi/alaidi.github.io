﻿using System;
using System.Collections.Generic;
using myUniversity;

class StudentComparer : IComparer<Student2>
{
    public SORTFIELD SortFields { get; set; } = SORTFIELD.ID;

    public SORTDIR SortDirs { get; set; } = SORTDIR.ASC;

    public int Compare(Student2 x, Student2 y)
    {
        int res = x.CompareTo(y, SortFields);
        if (SortDirs == SORTDIR.DESC)
            res = -1 * res;
        return res;
    }
}

public class Student4 : IComparable<Student>
{

    public int Id { get; set; }

    public int Test2Score { get; set; }

    public int Test1Score { get; set; }

    public string LastName { get; set; }

    public string FirstName { get; set; }

    public int CompareTo(Student4 st, SORTFIELD sField)
{
int res = 0;
    switch (sField)
{
    case SORTFIELD.FIRSTNAME:
    res = this.FirstName.CompareTo(st.FirstName);
    break;
    case SORTFIELD.LASTNAME:
    res = this.LastName.CompareTo(st.LastName);
    break;
    case SORTFIELD.ID:
    res = this.Id.CompareTo(st.Id);
    break;
    case SORTFIELD.TEST1SCORE:
    res = this.Test1Score.CompareTo(st.Test1Score);
    break;
    case SORTFIELD.TEST2SCORE:
    res = this.Test2Score.CompareTo(st.Test2Score);
    break;
}
return res;
}

    public int CompareTo(Student other)
    {
        throw new NotImplementedException();
    }
}


//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
//using WindowsFormsApp1.Entities;
//using myUniversity;

//namespace WindowsFormsApp1.Repository
//{
//    public class RepositoryProducts
//    {
//        // purpose of Repository is to compose SQL, issue it to DataAccess       
//        // and return a strongly typed data to the caller        
//       // readonly DataAccess _dataAccess = new DataAccess();
//        public List<Category> GetCategories()


//        {
//            List<Category> CList = new List<Category>();
//            try
//            {
//                string sql = "select * from Categories";
//                DataTable dt = DataAccess.GetMultitpleItems(sql, null);
//                // convert DataTable to List<Category>             
//                foreach (DataRow dr in dt.Rows)
//                {
//                    Category cat = new Category
//                    {
//                        CategoryId = (int)dr["CategoryId"],
//                        CategoryName = (string)dr["CategoryName"]
//                    };
//                    CList.Add(cat);
//                }
//            }
//            catch (Exception) { throw; }
//            return CList;
//        }

//        public List<Product> GetProductsByCategory(int catid)
//        {
//            List<Product> pList;
//            try
//            {
//                string sql = "select * from Products where CategoryId=@CategoryId";
//                var paramList = new List<SqlParameter>();
//                SqlParameter p1 = new SqlParameter("@categoryId", SqlDbType.Int) {Value = catid};
//                paramList.Add(p1);
//                DataTable dt = DataAccess.GetMultitpleItems(sql, paramList);
//                // convert DataTable to List<Product>       
//                pList = DBList.GetList<Product>(dt);
//            }
//            catch (Exception) { throw; }
//            return pList;
//        }

//        public bool AddProduct(Product pr)
//        {
//            bool ret = false; try
//            {
//                string sql = "insert into Products (ProductId,ProductName, Description," + "Price,StockLevel,CategoryId,OnSale,Discontinued) values (@ProductId," + "@ProductName,@Description,@Price,@StockLevel,@CategoryId,@OnSale," + "@Discontinued)";


//                var pList = new List<SqlParameter>();
//                DBHelper.AddSqlParam(pList, "@ProductId", SqlDbType.Int, pr.ProductId);
//                DBHelper.AddSqlParam(pList, "@ProductName", SqlDbType.VarChar, pr.ProductName, 50);
//                DBHelper.AddSqlParam(pList, "@Description", SqlDbType.Text, pr.Description);
//                DBHelper.AddSqlParam(pList, "@Price", SqlDbType.Money, pr.Price);
//                DBHelper.AddSqlParam(pList, "@StockLevel", SqlDbType.Int, pr.StockLevel);
//                DBHelper.AddSqlParam(pList, "@CategoryId", SqlDbType.Int, pr.CategoryId);
//                DBHelper.AddSqlParam(pList, "@OnSale", SqlDbType.Bit, pr.OnSale);
//                DBHelper.AddSqlParam(pList, "@Discontinued", SqlDbType.Bit, pr.Discontinued);

//                int rowsModified = DataAccess.InsertUpdateDelete(sql, pList); if (rowsModified > 0) ret = true;
//            }
//            catch (Exception) { throw; }
//            return ret;
//        }

//        public bool UpdateProduct(Product pr)
//        {
//            bool ret = false; try
//            {
//                string sql = "Update Products set ProductName=@ProductName," + "Description=@Description,Price=@Price,StockLevel=@StockLevel," + "CategoryId=@CategoryId,OnSale=@OnSale," + "Discontinued=@Discontinued where ProductId=@ProductId";
//                List<SqlParameter> pList = new List<SqlParameter>();
//                DBHelper.AddSqlParam(pList, "@ProductId", SqlDbType.Int, pr.ProductId);
//                DBHelper.AddSqlParam(pList, "@ProductName", SqlDbType.VarChar, pr.ProductName, 50);
//                DBHelper.AddSqlParam(pList, "@Description", SqlDbType.Text, pr.Description);
//                DBHelper.AddSqlParam(pList, "@Price", SqlDbType.Money, pr.Price);
//                DBHelper.AddSqlParam(pList, "@StockLevel", SqlDbType.Int, pr.StockLevel);
//                DBHelper.AddSqlParam(pList, "@CategoryId", SqlDbType.Int, pr.CategoryId);
//                DBHelper.AddSqlParam(pList, "@OnSale", SqlDbType.Bit, pr.OnSale);
//                DBHelper.AddSqlParam(pList, "@Discontinued", SqlDbType.Bit, pr.Discontinued);

//                int rowsModified = DataAccess.InsertUpdateDelete(sql, pList);
//                if (rowsModified > 0)
//                    ret = true;
//            }
//            catch (Exception) { throw; }
//            return ret;
//        }

//        public Product GetProduct(int pid)
//        {
//            Product pr = null; try
//            {
//                string sql = "select * from Products where ProductId=@ProductId";
//                List<SqlParameter> pList = new List<SqlParameter>();
//                DBHelper.AddSqlParam(pList, "@ProductId", SqlDbType.Int, pid);

//                DataTable dt = DataAccess.GetMultitpleItems(sql, pList);
//                if (dt.Rows.Count > 0)
//                {
//                    DataRow dr = dt.Rows[0];
//                    pr = new Product
//                    {
//                        ProductId = (int)dr["ProductId"],
//                        ProductName = (string)dr["ProductName"],
//                        Description = (string)dr["Description"],
//                        Price = (decimal)dr["Price"],
//                        StockLevel = (int)dr["StockLevel"],
//                        CategoryId = (int)dr["CategoryId"],
//                        OnSale = (bool)dr["OnSale"],
//                        Discontinued = (bool)dr["Discontinued"]
//                    };
//                }
//            }
//            catch (Exception) { throw; }
//            return pr;
//        }

//        public bool DeleteProduct(int pid)
//        {
//            bool ret = false;
//            try
//            {
//                string sql = "Delete from Products where ProductId=@ProductId";
//                List<SqlParameter> paramList = new List<SqlParameter>();
//                List<SqlParameter> pList = new List<SqlParameter>();
//                DBHelper.AddSqlParam(pList, "@ProductId", SqlDbType.Int, pid);
//                int rows = DataAccess.InsertUpdateDelete(sql, paramList); if (rows > 0) ret = true;
//            }
//            catch (Exception)
//            {
//                throw;


//            }
//            return ret;
//        }
//    }
//}
