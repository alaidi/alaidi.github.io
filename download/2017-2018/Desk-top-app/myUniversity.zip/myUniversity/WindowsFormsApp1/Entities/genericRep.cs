﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Entities
{
    class MyGen<T1, T2>
    {
        public T1 A { get; set; }
        public T2 B { get; set; }

        public override string ToString()
        {
            return A.ToString() + " : " + B.ToString();
        }
    }

    public class myRepository<T>
        where T : struct
    {
       public static K Add<K>(K a, K b)
            where K : struct
        {

            return a+b;
        }

    }
    public interface IRepository<T> where T : struct 
    {
        List<T> All();
        T Add(T t);
        int Delete(T t);
        int Update(T t);
    }

    public class EfRepository<T> : IRepository<T>
        where T : class
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public List<T> All()
        {
            throw new NotImplementedException();
        }

        public T Add(T t)
        {
            throw new NotImplementedException();
        }

        public int Delete(T t)
        {
            throw new NotImplementedException();
        }

        public int Update(T t)
        {
            throw new NotImplementedException();
        }
    }

    class genericRep
    {
    }
}
