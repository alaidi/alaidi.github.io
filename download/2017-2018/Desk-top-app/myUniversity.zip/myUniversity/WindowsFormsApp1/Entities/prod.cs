﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Entities
{
    public class Product : MyEntityBase
    {         //public int ProductId { get; set; }  
        public int ProductId { get; set; }

        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int StockLevel { get; set; }
        public int CategoryId { get; set; }
        public bool OnSale { get; set; }
        public bool Discontinued { get; set; }
    }
    public class ProductCatVM {
        public List<string/*SelectListItem*/> CatList { get; set; }
        public List<Product> PList { get; set; }
        public int categoryIdSelected { get; set; } }


}
