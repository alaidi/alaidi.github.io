USE [master]
GO

CREATE DATABASE [StudetntDB]

USE [StudetntDB]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[College](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Location] [nvarchar](250) NULL,
 CONSTRAINT [PK_College] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Department](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Department] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Student](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Birthday] [date] NOT NULL,
	[Gender] [bit] NULL,
 CONSTRAINT [PK_Studetns] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[UserTable]    Script Date: 4/24/2018 9:57:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserTable](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](150) NOT NULL,
	[Password] [nvarchar](max) NOT NULL,
	[salt] [nvarchar](max) NULL,
 CONSTRAINT [PK_UserTable] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET IDENTITY_INSERT [dbo].[College] ON 

GO
INSERT [dbo].[College] ([Id], [Name], [Location]) VALUES (1, N'Education', N'kut')
GO
INSERT [dbo].[College] ([Id], [Name], [Location]) VALUES (2, N'Eng', N'Kut')
GO
INSERT [dbo].[College] ([Id], [Name], [Location]) VALUES (3, N'Sci', N'Kut')
GO
INSERT [dbo].[College] ([Id], [Name], [Location]) VALUES (4, N'Basic Edu', N'Azezia')
GO
SET IDENTITY_INSERT [dbo].[College] OFF
GO
SET IDENTITY_INSERT [dbo].[Department] ON 

GO
INSERT [dbo].[Department] ([Id], [Name]) VALUES (1, N'Computer Scinece')
GO
INSERT [dbo].[Department] ([Id], [Name]) VALUES (3, N'History ')
GO
INSERT [dbo].[Department] ([Id], [Name]) VALUES (4, N'Electrical')
GO
INSERT [dbo].[Department] ([Id], [Name]) VALUES (1003, N'civil')
GO
SET IDENTITY_INSERT [dbo].[Department] OFF
GO
SET IDENTITY_INSERT [dbo].[UserTable] ON 

GO
INSERT [dbo].[UserTable] ([Id], [Name], [Password], [salt]) VALUES (1, N'ali', N'3c4996521690cc76446894da2bf7dd8f', NULL)
GO
INSERT [dbo].[UserTable] ([Id], [Name], [Password], [salt]) VALUES (2, N'mohammed', N'asdasd', NULL)
GO
SET IDENTITY_INSERT [dbo].[UserTable] OFF
GO
USE [master]
GO
ALTER DATABASE [StudetntDB] SET  READ_WRITE 
GO
